#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <Qfile>
#include <QTextStream>
#include <iostream>
#include <QPainter>
#include <QLabel>
#include <QRect>
#include <clickablelabel.h>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    readFile();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::readFile(){
    QFile file("/Users/phoebemirman/Desktop/Sudoku/map.txt");
    if (file.open(QIODevice::ReadOnly))
    {

        QTextStream in(&file);
        int z = 0;
        while(!in.atEnd()) {
            QString line = in.readLine();

            for (int i = 0; i < 9; i++) {
                grid[z][i] = line.at(i).digitValue();
            }
            z++;
        }

    }

    file.close();
}
void MainWindow::paintEvent(QPaintEvent*) {
    QPainter painter(this);

    painter.setPen(QPen(Qt::black,2));
    painter.drawRect(GridPos,GridPos,GridLength,GridLength);
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            ClickableLabel *label = new ClickableLabel(i,j);
            QRect rec(i*BoxLength+GridPos,j*BoxLength+GridPos,BoxLength, BoxLength);
            painter.drawRect(rec);
            if (grid[i][j] != 0) {
                painter.drawText(rec, Qt::AlignCenter,QString::number(grid[i][j]) );

            }
            label->setStyleSheet("border: 2px solid");
            label->setGeometry(rec); // one way to make boxes clickable
            lay->addWidget(label, 0,0);

        }

    }
    for (int i = 3; i < 9; i = i + 3) {
        painter.setPen(QPen(Qt::blue,2));
        painter.drawLine(BoxLength*i + GridPos, GridPos, BoxLength*i + GridPos, GridPos + GridLength);
        painter.drawLine(GridPos, BoxLength*i + GridPos, GridPos + GridLength, BoxLength*i + GridPos);
    }
}


void MainWindow::mousePressEvent( QMouseEvent* ev ) //other way to make boxes clickable
{
    const QPoint pt = ev->pos();
    std::cout<<pt.x()<<std::endl;

}
